//
// Created by danis on 11/30/2023.
//

#include "node.h"

node::node(Ticket t) : data(t), next(nullptr) {
    // Additional initialization if needed
}
