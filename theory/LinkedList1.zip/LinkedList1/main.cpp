#include <iostream>
#include "linklist.h"
#include "node.cpp"
#include "node.h"
#include "linklist.cpp"

int main() {
    // Create a Linklist object with integer data type
    Linklist<int> myList;

    // Add some elements to the list
    myList.addElement(5);
    myList.addElement(2);
    myList.addElement(8);
    myList.addElement(1);
    myList.addElement(9);

    // Print the unsorted list
    std::cout << "Unsorted List: " << myList << std::endl;

    // Perform bubble sort
    myList.bubble_sort();

    // Print the list after bubble sort
    std::cout << "Sorted List (Bubble Sort): " << myList << std::endl;

    // Clear the list
    myList.makeEmpty();

    // Add some elements to the list again
    myList.addElement(7);
    myList.addElement(3);
    myList.addElement(6);
    myList.addElement(4);
    myList.addElement(0);

    // Print the unsorted list
    std::cout << "Unsorted List: " << myList << std::endl;

    // Perform insert sort
    myList.insert_sort();

    // Print the list after insert sort
    std::cout << "Sorted List (Insert Sort): " << myList << std::endl;

    return 0;
}
